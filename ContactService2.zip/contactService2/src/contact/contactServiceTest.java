package contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



public class ContactServiceTest {

	@Test
	public void testAddContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Jack", "Smith", "1234567890", "123 Blue St");
		assertTrue(service.addContact(contact));
	}
	
	@Test
	public void testAddDuplicateContact() {
		ContactService service = new ContactService();
		Contact contact1 = new Contact("1", "Jack", "Smith", "1234567890", "123 Blue St");
		Contact contact2 = new Contact("1", "Jenny", "James", "1928374650", "2300 Jump St");
		service.addContact(contact1);
		assertFalse(service.addContact(contact2)); //for duplicate ID
	}
	@Test
	public void testDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Jack", "Smith", "1928374650", "123 Blue St" );
		service.addContact(contact);
		assertTrue(service.deleteContact("1"));
	}
	@Test
	public void testUpdateFirstName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Jenny", "James", "1234567890", "2300 Jump St");
		service.addContact(contact);
		service.updateFirstName("1", "Jack");
		assertEquals("Jack", service.getContact("1").getFirstName());
		
	}
	@Test
	public void testUpdateLastName() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Jane", "Doe", "3847561092", "123 Main St");
		service.addContact(contact);
		service.updateLastName("1","Smith");
		assertEquals("Smith", service.getContact("1").getLastName());
		
	}
	@Test
	public void testUpdatePhone() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "Jane", "Doe", "3847561092", "123 Main St");
		service.addContact(contact);
		service.updatePhone("1", "1234567890");
		assertEquals("1234567890", service.getContact("1").getPhone());
 	}
	
	@Test
	public void testUpdateAddress() {
		ContactService service = new ContactService();
		Contact contact = new Contact("1", "John", "Black","3847561092", "123 Jump St");
		service.addContact(contact);
		service.updateAddress("1",  "425 Balfour Dr");
		assertEquals("425 Balfour Dr", service.getContact("1").getAddress());
	}
}
