package contact;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;



public class ContactTest {

	// contact ID less than 10 char is valid
	@Test
	void testContactIdShorterThan10() {
		Contact contact = new Contact("12345", "Jane", "Lane", "1234567890", "425 Main St");
		assertEquals("12345", contact.getContactId());
		}
//contact ID with 10 char
	@Test
	void testContactIdExactly10() {
		Contact contact = new Contact("1234567890", "John", "Swift", "0987654321", "690 Rob St");
		assertEquals("1234567890", contact.getContactId());
	}

//contact ID than 10
	@Test
	void testContactIdLongerThan10 () {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "Alice", "Johnson", "8888888888", "2300 Jackson St");
		});
	}
}
