package contact;

import java.util.HashMap;
import java.util.Map;

public class contactService {
	private Map<String, Contact> contacts = new HashMap<>();
	
	//adding contacts
	public boolean addContact(Contact contact) {
		if (contacts.containsKey(contact.getContactId())) {
			return false; //to prevent duplication
		}
		contacts.put(contact.getContactId(),contact);
		return true;
	}
	//deleting contacts
	public boolean deleteContact(String contactId) {
		if (contacts.containsKey(contactId)) {
			contacts.remove(contactId);
			return true;
		}
		return false;
	}
	
	//updating first name
	public boolean updateFirstName(String contactId, String firstName) {
		Contact contact = contacts.get(contactId);
		if (contact != null) {
			contact.setFirstName(firstName);
			return true;
		}
		return false;
	}
	//updating last name
	public boolean updateLastName(String contactId, String lastName) {
		Contact contact = contacts.get(contactId);
		if (contact != null) {
			contact.setLastName(lastName);
			return true;
		}
		return false;
	}
	//updating phone number
	public boolean updatePhone(String contactId, String phone) {
		Contact contact = contacts.get(contactId);
		if (contact !=null) {
			contact.setPhone(phone);
			return true;
		}
		return false;
	}
	//updating the address
	public boolean updateAddress(String contactId, String address) {
		Contact contact = contacts.get(contactId);
		if (contact != null) {
			contact.setAddress(address);
			return true;
		}
		return false;
	}
	
}
